﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace waveShifter {
    public delegate void SolutionDelegate();
    public delegate void IntDelegate(int i);
}
